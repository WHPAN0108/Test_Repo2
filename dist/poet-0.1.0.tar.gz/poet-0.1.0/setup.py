# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poet', 'poet.poet', 'poet.tests']

package_data = \
{'': ['*'], 'poet': ['.pytest_cache/*', '.pytest_cache/v/cache/*']}

install_requires = \
['requests>=2.27.1,<3.0.0']

setup_kwargs = {
    'name': 'poet',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'WEI',
    'author_email': 'w.pan@silence-theraptic.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
